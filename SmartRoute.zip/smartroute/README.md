# SmartRoute — Intelligent Dynamic Route Optimization System

A capstone-level, fully interactive demo of **Dijkstra's algorithm** and **A\* search**
applied to a simulated Chennai-area road network. Built with React + Vite, no backend
or paid APIs required — everything runs locally in the browser.

> Distances, coordinates, and traffic values are **simulated for demonstration purposes**
> and do not reflect real survey data.

---

## 1. Running it in VS Code

**Requirements:** [Node.js 18+](https://nodejs.org) installed on your machine.

1. Unzip the project and open the `smartroute` folder in VS Code (`File → Open Folder…`).
2. Open a terminal in VS Code: `Terminal → New Terminal` (or `` Ctrl+` ``).
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the dev server:
   ```bash
   npm run dev
   ```
5. Open **http://localhost:5173** in your browser (it should open automatically).

That's it — no database, no API keys, no backend to configure.

**Other useful commands:**
| Command | What it does |
|---|---|
| `npm run build` | Builds an optimized production bundle into `dist/` |
| `npm run preview` | Serves the production build locally to sanity-check it |

---

## 2. How to use the demo

1. Pick a **Start Location** and **Destination** in the left sidebar.
2. Choose **Dijkstra** or **A\*** and a **Route Preference**.
3. Click **Calculate Route** — the algorithm runs and animates step-by-step on the map:
   Gray = unvisited · Yellow (pulsing) = exploring · Blue = visited · Green = shortest path ·
   Red dashed = closed road · Orange = heavy/severe traffic.
4. Watch the **Live Execution** panel and console log update in real time.
5. Use **Pause / Resume**, **Run Animation** (replay), **Reset**, and the speed slider.
6. Select a road (on the map or from the dropdown) to change its **traffic level** or
   **close it**, then recalculate to see the route adapt.
7. Click **Compare Algorithms** for a Dijkstra vs A* stats + bar-chart comparison.
8. Expand **"How Dijkstra Works"** for complexity notes, and check the **Capstone
   Dashboard** for live network stats.

The default scenario (Chennai Central → Kelambakkam) is preloaded, so you can hit
**Calculate Route** immediately.

---

## 3. Project structure

```
smartroute/
├── src/
│   ├── algorithms/        dijkstra.js, astar.js, priorityQueue.js (manual implementations)
│   ├── components/        MapGraph, ControlPanel, RouteInfo, AlgorithmVisualizer,
│   │                      ComparisonPanel, Dashboard, ExplanationPanel
│   ├── data/               locations.js (25 nodes), roads.js (~38 weighted edges)
│   ├── utils/              graphUtils.js, pathReconstruction.js
│   ├── App.jsx             wires state, algorithms, and UI together
│   ├── index.css           HUD-style dark theme
│   └── main.jsx
├── index.html
├── package.json
└── vite.config.js
```

---

## 4. Dijkstra implementation

Implemented manually in `src/algorithms/dijkstra.js` — **no routing library used.**

Distances start at `Infinity` (source = 0) → source is pushed into a **binary min-heap
priority queue** (`priorityQueue.js`) → the algorithm repeatedly pops the closest
unvisited node → relaxes each neighboring edge, updating the distance table and a
`previous`-node map whenever a shorter path is found → continues until the destination
is popped → the final path is **reconstructed** by walking backwards through `previous`.

Every operation is recorded into a `steps[]` trace, which drives the on-screen animation
and console log directly — the visualization is a real trace of the algorithm, not scripted.

- **Time complexity:** `O((V + E) log V)`
- **Space complexity:** `O(V + E)`

## 5. A* implementation

`src/algorithms/astar.js` is structurally identical to Dijkstra but orders the priority
queue by `f(n) = g(n) + h(n)`, where `g(n)` is the real cost-so-far and `h(n)` is a
**Euclidean-distance heuristic** from each node's `x, y` coordinate to the destination
(`heuristic()` in `graphUtils.js`). Because the heuristic never overestimates the true
remaining distance, A* finds the same shortest path as Dijkstra but typically visits
**fewer nodes** — visible directly in the Compare Algorithms panel.

## 6. Graph data structure

`locations.js` defines 25 Chennai-inspired nodes with coordinates (used for the SVG
layout and the A* heuristic). `roads.js` defines ~38 undirected weighted edges.
`buildAdjacencyList()` turns this into a proper adjacency list at runtime, excluding
any closed roads.

## 7. Traffic model

Each road has a traffic level (`LOW`/`MEDIUM`/`HIGH`/`SEVERE`) mapped to a multiplier
(1.0 / 1.3 / 2.0 / 3.0). `edgeCost()` computes the effective cost per Route Preference:
Shortest Distance ignores traffic, Fastest Route scales by the factor, Avoid Traffic
squares the factor, Balanced averages the two.

## 8. Road closure system

Closing a road flips a `closed` flag; `buildAdjacencyList()` skips closed edges
entirely, so they are structurally removed from the search space — not just penalized.
Recalculating shows the algorithm finding a genuinely different valid route.

## 9. How the animation works

Both algorithms return a full `steps[]` trace generated while they actually run.
`App.jsx` advances an `animIndex` on a timer, and every component (map colors, live
stats, distance table, console log) renders however much of the trace has played so
far — pause/resume/speed only control playback rate, never the underlying data.
