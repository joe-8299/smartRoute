import { useState, useMemo, useEffect, useRef, useCallback } from 'react'
import { locations, locationById } from './data/locations.js'
import { buildInitialRoads } from './data/roads.js'
import { buildAdjacencyList } from './utils/graphUtils.js'
import { dijkstra } from './algorithms/dijkstra.js'
import { astar } from './algorithms/astar.js'

import MapGraph from './components/MapGraph.jsx'
import ControlPanel from './components/ControlPanel.jsx'
import RouteInfo from './components/RouteInfo.jsx'
import AlgorithmVisualizer from './components/AlgorithmVisualizer.jsx'
import ComparisonPanel from './components/ComparisonPanel.jsx'
import Dashboard from './components/Dashboard.jsx'
import ExplanationPanel from './components/ExplanationPanel.jsx'

const ANIM_BASE_MS = 700

export default function App() {
  const [roads, setRoads] = useState(buildInitialRoads)
  const [source, setSource] = useState('chennai')
  const [destination, setDestination] = useState('kelambakkam')
  const [algorithm, setAlgorithm] = useState('dijkstra')
  const [mode, setMode] = useState('distance')
  const [selectedRoadId, setSelectedRoadId] = useState(null)

  const [result, setResult] = useState(null)
  const [animIndex, setAnimIndex] = useState(-1)
  const [isPlaying, setIsPlaying] = useState(false)
  const [speed, setSpeed] = useState(1.5)

  const [comparison, setComparison] = useState(null)
  const [stats, setStats] = useState({ routesCalculated: 0, totalNodesExplored: 0 })

  const timerRef = useRef(null)

  const adjacencyList = useMemo(() => buildAdjacencyList(locations, roads), [roads])

  const runAlgorithm = useCallback((algo = algorithm, m = mode) => {
    if (source === destination) return null
    return algo === 'dijkstra'
      ? dijkstra(adjacencyList, roads, source, destination, m)
      : astar(adjacencyList, roads, locationById, source, destination, m)
  }, [adjacencyList, roads, source, destination, algorithm, mode])

  const handleCalculate = () => {
    clearInterval(timerRef.current)
    const res = runAlgorithm()
    if (!res) return
    setResult(res)
    setAnimIndex(0)
    setIsPlaying(true)
    setComparison(null)
  }

  const handleRunAnimation = () => {
    if (!result) return
    clearInterval(timerRef.current)
    setAnimIndex(0)
    setIsPlaying(true)
  }

  const handlePause = () => {
    if (!result) return
    setIsPlaying(p => !p)
  }

  const handleReset = () => {
    clearInterval(timerRef.current)
    setResult(null)
    setAnimIndex(-1)
    setIsPlaying(false)
    setComparison(null)
  }

  const handleCompare = () => {
    if (source === destination) return
    const d = runAlgorithm('dijkstra')
    const a = runAlgorithm('astar')
    if (d && a) setComparison({ dijkstra: d, astar: a })
  }

  const handleSetTraffic = (roadId, level) => {
    setRoads(prev => ({ ...prev, [roadId]: { ...prev[roadId], traffic: level } }))
  }

  const handleToggleClosed = (roadId) => {
    setRoads(prev => ({ ...prev, [roadId]: { ...prev[roadId], closed: !prev[roadId].closed } }))
  }

  useEffect(() => {
    if (!isPlaying || !result) return
    clearInterval(timerRef.current)
    timerRef.current = setInterval(() => {
      setAnimIndex(prev => {
        if (prev + 1 >= result.steps.length) {
          clearInterval(timerRef.current)
          setIsPlaying(false)
          setStats(s => ({
            routesCalculated: s.routesCalculated + 1,
            totalNodesExplored: s.totalNodesExplored + result.nodesExplored,
          }))
          return prev
        }
        return prev + 1
      })
    }, ANIM_BASE_MS / speed)
    return () => clearInterval(timerRef.current)
  }, [isPlaying, result, speed])

  const animComplete = result && animIndex >= result.steps.length - 1
  const visibleSteps = result ? result.steps.slice(0, animIndex + 1) : []
  const visited = new Set(visibleSteps.filter(s => s.type === 'visit').map(s => s.node))
  const currentStep = visibleSteps[visibleSteps.length - 1]
  const currentNode = currentStep?.type === 'visit' ? currentStep.node : null
  const lastRelax = [...visibleSteps].reverse().find(s => s.type === 'relax')
  const lastEdge = lastRelax ? [lastRelax.from, lastRelax.to].sort().join('__') : null
  const pathNodes = animComplete ? result.path : null

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark" />
          <div>
            <h1>SmartRoute</h1>
            <p>Intelligent Dynamic Route Optimization</p>
          </div>
        </div>
        <div className="brand-note">Simulated distances &amp; traffic — Chennai-inspired demo network</div>
      </header>

      <main className="layout">
        <ControlPanel
          locations={locations}
          roads={roads}
          source={source} destination={destination}
          setSource={setSource} setDestination={setDestination}
          algorithm={algorithm} setAlgorithm={setAlgorithm}
          mode={mode} setMode={setMode}
          selectedRoadId={selectedRoadId} setSelectedRoadId={setSelectedRoadId}
          onSetTraffic={handleSetTraffic}
          onToggleClosed={handleToggleClosed}
          onCalculate={handleCalculate}
          onRunAnimation={handleRunAnimation}
          onPause={handlePause}
          isPlaying={isPlaying}
          onReset={handleReset}
          onCompare={handleCompare}
          speed={speed} setSpeed={setSpeed}
          hasResult={!!result}
        />

        <div className="center-col">
          <div className="map-wrap panel">
            <MapGraph
              locations={locations}
              roads={roads}
              source={source}
              destination={destination}
              visited={visited}
              currentNode={currentNode}
              pathNodes={pathNodes}
              lastEdge={lastEdge}
              selectedRoadId={selectedRoadId}
              onSelectRoad={setSelectedRoadId}
            />
            <div className="legend">
              <span><i className="dot gray" /> Unvisited</span>
              <span><i className="dot yellow" /> Exploring</span>
              <span><i className="dot blue" /> Visited</span>
              <span><i className="dot green" /> Shortest Path</span>
              <span><i className="dot red" /> Closed</span>
              <span><i className="dot orange" /> Heavy Traffic</span>
            </div>
          </div>

          <AlgorithmVisualizer
            steps={result?.steps || []}
            animIndex={animIndex}
            algorithm={result?.algorithm || algorithm}
          />

          <ExplanationPanel />
          <Dashboard locations={locations} roads={roads} stats={stats} />
        </div>

        <RouteInfo result={result} animComplete={animComplete} />
      </main>

      {comparison && <ComparisonPanel comparison={comparison} onClose={() => setComparison(null)} />}
    </div>
  )
}
