import { locationById } from '../data/locations.js'
import { estimateMinutes } from '../utils/graphUtils.js'

export default function RouteInfo({ result, animComplete }) {
  if (!result) {
    return (
      <aside className="panel sidebar-right">
        <h3>Route Information</h3>
        <p className="muted">Set a start and destination, then click <strong>Calculate Route</strong> to begin.</p>
      </aside>
    )
  }

  const { path, distance, algorithm, nodesExplored, executionTime } = result
  const minutes = distance != null ? estimateMinutes(distance) : null

  return (
    <aside className="panel sidebar-right">
      <h3>Route Information</h3>

      {!path && (
        <p className="muted warn">No route could be found between these locations with the current road conditions.</p>
      )}

      {path && (
        <>
          <div className="stat-grid">
            <div className="stat">
              <span className="stat-label">Distance</span>
              <span className="stat-value">{distance.toFixed(1)} km</span>
            </div>
            <div className="stat">
              <span className="stat-label">Est. Time</span>
              <span className="stat-value">{minutes} min</span>
            </div>
            <div className="stat">
              <span className="stat-label">Algorithm</span>
              <span className="stat-value">{algorithm}</span>
            </div>
            <div className="stat">
              <span className="stat-label">Nodes Explored</span>
              <span className="stat-value">{animComplete ? nodesExplored : '…'}</span>
            </div>
            <div className="stat">
              <span className="stat-label">Execution Time</span>
              <span className="stat-value">{executionTime.toFixed(2)} ms</span>
            </div>
          </div>

          {animComplete && (
            <div className="route-path">
              <h4>Shortest Route</h4>
              <ol>
                {path.map((id, i) => (
                  <li key={id}>
                    {locationById[id].name}
                    {i < path.length - 1 && <span className="arrow">↓</span>}
                  </li>
                ))}
              </ol>
            </div>
          )}
        </>
      )}
    </aside>
  )
}
