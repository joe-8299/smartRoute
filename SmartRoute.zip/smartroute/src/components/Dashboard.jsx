export default function Dashboard({ locations, roads, stats }) {
  const roadList = Object.values(roads)
  const blocked = roadList.filter(r => r.closed).length
  const active = roadList.length - blocked
  const avgExplored = stats.routesCalculated > 0
    ? (stats.totalNodesExplored / stats.routesCalculated).toFixed(1)
    : '—'

  const items = [
    ['Total Locations', locations.length],
    ['Total Roads', roadList.length],
    ['Active Roads', active],
    ['Blocked Roads', blocked],
    ['Routes Calculated', stats.routesCalculated],
    ['Avg. Nodes Explored', avgExplored],
  ]

  return (
    <section className="panel dashboard">
      <h3>Capstone Dashboard</h3>
      <div className="dashboard-grid">
        {items.map(([label, value]) => (
          <div key={label} className="dash-tile">
            <span className="dash-value">{value}</span>
            <span className="dash-label">{label}</span>
          </div>
        ))}
      </div>
    </section>
  )
}
