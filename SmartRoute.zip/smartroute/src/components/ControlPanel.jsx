import { TRAFFIC_FACTORS } from '../data/roads.js'

export default function ControlPanel({
  locations, roads,
  source, destination, setSource, setDestination,
  algorithm, setAlgorithm,
  mode, setMode,
  selectedRoadId, setSelectedRoadId,
  onSetTraffic, onToggleClosed,
  onCalculate, onRunAnimation, onPause, isPlaying,
  onReset, onCompare,
  speed, setSpeed,
  hasResult,
}) {
  const roadList = Object.values(roads).sort((a, b) => a.from.localeCompare(b.from))
  const selectedRoad = selectedRoadId ? roads[selectedRoadId] : null
  const fromName = (id) => locations.find(l => l.id === id)?.name

  return (
    <aside className="panel sidebar-left">
      <section className="panel-section">
        <h3>Route</h3>
        <label className="field">
          <span>Start Location</span>
          <select value={source} onChange={(e) => setSource(e.target.value)}>
            {locations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
          </select>
        </label>
        <label className="field">
          <span>Destination</span>
          <select value={destination} onChange={(e) => setDestination(e.target.value)}>
            {locations.map(l => <option key={l.id} value={l.id}>{l.name}</option>)}
          </select>
        </label>
        <label className="field">
          <span>Algorithm</span>
          <div className="segmented">
            <button className={algorithm === 'dijkstra' ? 'active' : ''} onClick={() => setAlgorithm('dijkstra')}>Dijkstra</button>
            <button className={algorithm === 'astar' ? 'active' : ''} onClick={() => setAlgorithm('astar')}>A*</button>
          </div>
        </label>
        <label className="field">
          <span>Route Preference</span>
          <select value={mode} onChange={(e) => setMode(e.target.value)}>
            <option value="distance">Shortest Distance</option>
            <option value="fastest">Fastest Route</option>
            <option value="traffic">Avoid Traffic</option>
            <option value="balanced">Balanced</option>
          </select>
        </label>
      </section>

      <section className="panel-section">
        <h3>Traffic Controls</h3>
        <label className="field">
          <span>Select Road</span>
          <select value={selectedRoadId || ''} onChange={(e) => setSelectedRoadId(e.target.value)}>
            <option value="">— choose a road —</option>
            {roadList.map(r => (
              <option key={r.id} value={r.id}>{fromName(r.from)} ↔ {fromName(r.to)}</option>
            ))}
          </select>
        </label>
        {selectedRoad && (
          <>
            <div className="traffic-buttons">
              {Object.keys(TRAFFIC_FACTORS).map(level => (
                <button
                  key={level}
                  className={`traffic-btn traffic-${level} ${selectedRoad.traffic === level ? 'active' : ''}`}
                  onClick={() => onSetTraffic(selectedRoad.id, level)}
                  disabled={selectedRoad.closed}
                >
                  {level}
                </button>
              ))}
            </div>
            <button
              className={`road-close-btn ${selectedRoad.closed ? 'closed' : ''}`}
              onClick={() => onToggleClosed(selectedRoad.id)}
            >
              {selectedRoad.closed ? 'Reopen Road' : 'Close Road'}
            </button>
          </>
        )}
      </section>

      <section className="panel-section actions">
        <h3>Actions</h3>
        <button className="btn-primary" onClick={onCalculate}>Calculate Route</button>
        <div className="btn-row">
          <button onClick={onRunAnimation} disabled={!hasResult}>Run Animation</button>
          <button onClick={onPause} disabled={!hasResult}>{isPlaying ? 'Pause' : 'Resume'}</button>
        </div>
        <div className="btn-row">
          <button onClick={onReset}>Reset</button>
          <button onClick={onCompare}>Compare Algorithms</button>
        </div>
        <label className="field speed-field">
          <span>Animation Speed: {speed}×</span>
          <input type="range" min="0.5" max="4" step="0.5" value={speed} onChange={(e) => setSpeed(Number(e.target.value))} />
        </label>
      </section>
    </aside>
  )
}
