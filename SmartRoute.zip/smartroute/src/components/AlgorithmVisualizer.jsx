import { useMemo, useEffect, useRef } from 'react'
import { locationById } from '../data/locations.js'

function formatTimestamp(i) {
  const totalSeconds = i + 1
  const mm = String(Math.floor(totalSeconds / 60)).padStart(2, '0')
  const ss = String(totalSeconds % 60).padStart(2, '0')
  return `[${mm}:${ss}]`
}

export default function AlgorithmVisualizer({ steps, animIndex, algorithm }) {
  const consoleRef = useRef(null)
  const visible = steps.slice(0, animIndex + 1)
  const current = visible[visible.length - 1]

  const distances = useMemo(() => {
    const table = {}
    for (const s of visible) {
      if (s.type === 'init') Object.assign(table, s.distances)
      if (s.type === 'relax') table[s.to] = s.newDistance
    }
    return table
  }, [visible])

  const nodesExploredSoFar = useMemo(
    () => visible.filter(s => s.type === 'visit').length,
    [visible]
  )

  useEffect(() => {
    if (consoleRef.current) consoleRef.current.scrollTop = consoleRef.current.scrollHeight
  }, [animIndex])

  if (!steps.length) {
    return (
      <section className="panel console-panel">
        <h3>Algorithm Visualization Console</h3>
        <p className="muted">Run an algorithm to see live execution steps here.</p>
      </section>
    )
  }

  const pq = current?.pq || []
  const sortedDistances = Object.entries(distances).sort((a, b) => a[1] - b[1])

  return (
    <section className="panel console-panel">
      <div className="console-top">
        <div className="live-stats">
          <h3>Live Execution — {algorithm}</h3>
          <div className="stat-grid compact">
            <div className="stat"><span className="stat-label">Current Node</span><span className="stat-value">{current?.node ? locationById[current.node]?.name : '—'}</span></div>
            <div className="stat"><span className="stat-label">Current Distance</span><span className="stat-value">{current?.distance != null ? current.distance.toFixed(1) + ' km' : '—'}</span></div>
            <div className="stat"><span className="stat-label">Nodes Explored</span><span className="stat-value">{nodesExploredSoFar}</span></div>
          </div>
          <div className="pq-box">
            <span className="stat-label">Priority Queue</span>
            <code>[{pq.map(([p, n]) => `(${p}, ${n})`).join(', ') || '—'}]</code>
          </div>
        </div>

        <div className="distance-table">
          <span className="stat-label">Distance Table</span>
          <div className="table-scroll">
            <table>
              <thead><tr><th>Node</th><th>Distance</th></tr></thead>
              <tbody>
                {sortedDistances.map(([node, d]) => (
                  <tr key={node}>
                    <td>{locationById[node]?.name}</td>
                    <td>{d === Infinity ? '∞' : d.toFixed(1)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      <div className="console-log" ref={consoleRef}>
        {visible.map((s, i) => (
          <div key={i} className={`log-line log-${s.type}`}>
            <span className="log-ts">{formatTimestamp(i)}</span> {s.message}
          </div>
        ))}
      </div>
    </section>
  )
}
