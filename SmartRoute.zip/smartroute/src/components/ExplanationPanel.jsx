import { useState } from 'react'

const STEPS = [
  'Start from the source node.',
  'Set the source distance to 0, all others to infinity.',
  'Select the closest unvisited node from the priority queue.',
  'Relax its neighboring edges — check if going through this node is shorter.',
  'Update distances and previous-node pointers where a shorter path is found.',
  'Repeat until the destination is popped from the queue.',
  'Reconstruct the shortest path by walking backwards through previous-node pointers.',
]

export default function ExplanationPanel() {
  const [open, setOpen] = useState(false)

  return (
    <section className="panel explanation-panel">
      <button className="explanation-toggle" onClick={() => setOpen(o => !o)}>
        <span>How Dijkstra Works</span>
        <span className={`chev ${open ? 'open' : ''}`}>▾</span>
      </button>
      {open && (
        <div className="explanation-body">
          <ol>
            {STEPS.map((s, i) => <li key={i}>{s}</li>)}
          </ol>
          <div className="complexity-row">
            <div>
              <span className="stat-label">Time Complexity</span>
              <code>O((V + E) log V)</code>
            </div>
            <div>
              <span className="stat-label">Space Complexity</span>
              <code>O(V + E)</code>
            </div>
          </div>
          <p className="muted small">V = number of vertices (locations), E = number of edges (roads).</p>
        </div>
      )}
    </section>
  )
}
