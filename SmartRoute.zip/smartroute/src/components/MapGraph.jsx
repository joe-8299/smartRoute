import { locationById } from '../data/locations.js'
import { makeRoadId } from '../data/roads.js'

const STATE_COLORS = {
  gray: '#3a4556',
  yellow: '#ffcc33',
  blue: '#2fb8ff',
  green: '#3ddc84',
}

export default function MapGraph({
  locations,
  roads,
  source,
  destination,
  visited,
  currentNode,
  pathNodes,
  lastEdge,
  selectedRoadId,
  onSelectRoad,
}) {
  const pathEdgeIds = new Set()
  if (pathNodes && pathNodes.length > 1) {
    for (let i = 0; i < pathNodes.length - 1; i++) {
      pathEdgeIds.add(makeRoadId(pathNodes[i], pathNodes[i + 1]))
    }
  }

  const nodeState = (id) => {
    if (pathNodes?.includes(id)) return 'green'
    if (id === currentNode) return 'yellow'
    if (visited?.has(id)) return 'blue'
    return 'gray'
  }

  return (
    <svg viewBox="0 0 640 600" className="map-svg" role="img" aria-label="Chennai road network graph">
      <defs>
        <pattern id="gridPattern" width="32" height="32" patternUnits="userSpaceOnUse">
          <path d="M 32 0 L 0 0 0 32" fill="none" stroke="#182233" strokeWidth="1" />
        </pattern>
        <filter id="glow" x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="3.2" result="blur" />
          <feMerge>
            <feMergeNode in="blur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>

      <rect x="0" y="0" width="640" height="600" fill="url(#gridPattern)" />

      {Object.values(roads).map((road) => {
        const a = locationById[road.from]
        const b = locationById[road.to]
        const isPath = pathEdgeIds.has(road.id)
        const isLast = lastEdge && road.id === lastEdge
        const isSelected = selectedRoadId === road.id

        let stroke = STATE_COLORS.gray
        let width = 2
        let dash = 'none'
        let filter = 'none'

        if (road.closed) {
          stroke = '#ff4d5e'
          dash = '6 4'
        } else if (road.traffic === 'HIGH' || road.traffic === 'SEVERE') {
          stroke = road.traffic === 'SEVERE' ? '#ff5a1f' : '#ff9d33'
        }
        if (isPath) {
          stroke = STATE_COLORS.green
          width = 4
          filter = 'url(#glow)'
        } else if (isLast) {
          stroke = STATE_COLORS.yellow
          width = 3
          filter = 'url(#glow)'
        }
        if (isSelected) {
          width += 1.5
        }

        const mx = (a.x + b.x) / 2
        const my = (a.y + b.y) / 2

        return (
          <g key={road.id} className="road-group" onClick={() => onSelectRoad?.(road.id)} style={{ cursor: 'pointer' }}>
            <line x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke="transparent" strokeWidth={14} />
            <line
              x1={a.x} y1={a.y} x2={b.x} y2={b.y}
              stroke={stroke} strokeWidth={width} strokeDasharray={dash} filter={filter}
              className={isPath ? 'edge-path' : ''}
            />
            <rect x={mx - 13} y={my - 8} width={26} height={14} rx={3} fill="#0b111c" opacity={0.85} />
            <text x={mx} y={my + 3} textAnchor="middle" className="edge-weight">
              {road.closed ? '✕' : road.baseDistance}
            </text>
            {isSelected && (
              <text x={mx} y={my - 12} textAnchor="middle" className="edge-selected-label">SELECTED</text>
            )}
          </g>
        )
      })}

      {locations.map((loc) => {
        const state = nodeState(loc.id)
        const isEndpoint = loc.id === source || loc.id === destination
        const r = isEndpoint ? 9 : 6.5
        return (
          <g key={loc.id} className="node-group">
            {loc.id === currentNode && (
              <circle cx={loc.x} cy={loc.y} r={r + 7} fill="none" stroke={STATE_COLORS.yellow} strokeWidth={1.5} opacity={0.6}>
                <animate attributeName="r" values={`${r + 4};${r + 12};${r + 4}`} dur="1.4s" repeatCount="indefinite" />
                <animate attributeName="opacity" values="0.7;0;0.7" dur="1.4s" repeatCount="indefinite" />
              </circle>
            )}
            <circle
              cx={loc.x} cy={loc.y} r={r}
              fill={STATE_COLORS[state]}
              stroke={isEndpoint ? '#e8f4ff' : '#0b111c'}
              strokeWidth={isEndpoint ? 2 : 1}
              filter={state !== 'gray' ? 'url(#glow)' : 'none'}
            />
            <text x={loc.x} y={loc.y - r - 6} textAnchor="middle" className="node-label">
              {loc.name}
            </text>
            {loc.id === source && <text x={loc.x} y={loc.y + r + 14} textAnchor="middle" className="node-tag tag-start">START</text>}
            {loc.id === destination && <text x={loc.x} y={loc.y + r + 14} textAnchor="middle" className="node-tag tag-end">END</text>}
          </g>
        )
      })}
    </svg>
  )
}
