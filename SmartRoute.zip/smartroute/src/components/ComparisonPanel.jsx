export default function ComparisonPanel({ comparison, onClose }) {
  if (!comparison) return null
  const { dijkstra, astar } = comparison

  const maxNodes = Math.max(dijkstra.nodesExplored, astar.nodesExplored, 1)
  const maxTime = Math.max(dijkstra.executionTime, astar.executionTime, 0.01)

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal comparison-modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h3>Dijkstra vs A*</h3>
          <button className="close-btn" onClick={onClose}>✕</button>
        </div>

        <table className="comparison-table">
          <thead>
            <tr><th></th><th>Dijkstra</th><th>A*</th></tr>
          </thead>
          <tbody>
            <tr><td>Distance</td><td>{dijkstra.path ? dijkstra.distance.toFixed(1) + ' km' : '—'}</td><td>{astar.path ? astar.distance.toFixed(1) + ' km' : '—'}</td></tr>
            <tr><td>Nodes Explored</td><td>{dijkstra.nodesExplored}</td><td>{astar.nodesExplored}</td></tr>
            <tr><td>Execution Time</td><td>{dijkstra.executionTime.toFixed(2)} ms</td><td>{astar.executionTime.toFixed(2)} ms</td></tr>
            <tr><td>Route Found</td><td>{dijkstra.path ? 'Yes' : 'No'}</td><td>{astar.path ? 'Yes' : 'No'}</td></tr>
          </tbody>
        </table>

        <div className="bar-chart">
          <div className="bar-group">
            <span className="bar-title">Nodes Explored</span>
            <div className="bar-row"><span className="bar-label">Dijkstra</span><div className="bar-track"><div className="bar-fill dijkstra" style={{ width: `${(dijkstra.nodesExplored / maxNodes) * 100}%` }} /></div><span>{dijkstra.nodesExplored}</span></div>
            <div className="bar-row"><span className="bar-label">A*</span><div className="bar-track"><div className="bar-fill astar" style={{ width: `${(astar.nodesExplored / maxNodes) * 100}%` }} /></div><span>{astar.nodesExplored}</span></div>
          </div>
          <div className="bar-group">
            <span className="bar-title">Execution Time (ms)</span>
            <div className="bar-row"><span className="bar-label">Dijkstra</span><div className="bar-track"><div className="bar-fill dijkstra" style={{ width: `${(dijkstra.executionTime / maxTime) * 100}%` }} /></div><span>{dijkstra.executionTime.toFixed(2)}</span></div>
            <div className="bar-row"><span className="bar-label">A*</span><div className="bar-track"><div className="bar-fill astar" style={{ width: `${(astar.executionTime / maxTime) * 100}%` }} /></div><span>{astar.executionTime.toFixed(2)}</span></div>
          </div>
        </div>

        <div className="comparison-explain">
          <p><strong>Dijkstra</strong> explores based on the current shortest known distance from the source — it expands outward in all directions equally.</p>
          <p><strong>A*</strong> uses a heuristic (straight-line distance to the destination) to guide the search, so it explores fewer irrelevant nodes.</p>
        </div>
      </div>
    </div>
  )
}
