// Reconstructs the shortest path from a `previous` map produced by
// Dijkstra or A*, walking backwards from destination to source.
export function reconstructPath(previous, source, destination) {
  const path = []
  let current = destination

  if (current !== source && previous[current] === undefined) {
    return null // unreachable
  }

  while (current !== undefined) {
    path.unshift(current)
    if (current === source) break
    current = previous[current]
  }

  return path[0] === source ? path : null
}
