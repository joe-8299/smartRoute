import { TRAFFIC_FACTORS, makeRoadId } from '../data/roads.js'

// Build an adjacency list: { nodeId: [{ to, roadId }, ...] }
export function buildAdjacencyList(locations, roads) {
  const adj = {}
  for (const loc of locations) adj[loc.id] = []
  for (const roadId in roads) {
    const road = roads[roadId]
    if (road.closed) continue
    adj[road.from].push({ to: road.to, roadId })
    adj[road.to].push({ to: road.from, roadId })
  }
  return adj
}

// Effective travel cost for a road, depending on route preference mode.
// Modes: 'distance' | 'fastest' | 'traffic' | 'balanced'
export function edgeCost(road, mode = 'distance') {
  const factor = TRAFFIC_FACTORS[road.traffic] ?? 1
  const base = road.baseDistance

  switch (mode) {
    case 'distance':
      return base
    case 'fastest':
      return base * factor
    case 'traffic':
      return base * factor * factor
    case 'balanced':
    default:
      return base * 0.5 + base * factor * 0.5
  }
}

// Straight-line (Euclidean) distance between two node coordinates,
// scaled down to be a comparable "km-like" unit for the A* heuristic.
export function heuristic(a, b) {
  const dx = a.x - b.x
  const dy = a.y - b.y
  return Math.sqrt(dx * dx + dy * dy) / 12
}

export function estimateMinutes(distanceKm, avgTraffic = 'LOW') {
  const speedKmh = 40 // simulated average city speed
  return Math.round((distanceKm / speedKmh) * 60)
}

export function getRoad(roads, a, b) {
  return roads[makeRoadId(a, b)]
}
