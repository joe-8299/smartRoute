import { PriorityQueue } from './priorityQueue.js'
import { edgeCost, heuristic } from '../utils/graphUtils.js'
import { reconstructPath } from '../utils/pathReconstruction.js'

/**
 * A* Search — manual implementation.
 *
 * f(n) = g(n) + h(n)
 *   g(n) = actual cost from source to n (like Dijkstra's distance)
 *   h(n) = estimated cost from n to destination (Euclidean heuristic)
 *
 * The heuristic guides the search toward the destination, so A*
 * typically explores far fewer nodes than plain Dijkstra while still
 * guaranteeing the shortest path (since the heuristic never overestimates).
 *
 * Time complexity:  O((V + E) log V)
 * Space complexity: O(V + E)
 */
export function astar(adjacencyList, roads, locationById, source, destination, mode = 'distance') {
  const startTime = performance.now()

  const gScore = {}
  const previous = {}
  const visited = new Set()
  const steps = []

  for (const node in adjacencyList) gScore[node] = Infinity
  gScore[source] = 0

  const destCoord = locationById[destination]
  const h = (nodeId) => heuristic(locationById[nodeId], destCoord)

  const pq = new PriorityQueue()
  pq.push(source, h(source))

  steps.push({
    type: 'init',
    message: `Starting A* from ${source}. f(n) = g(n) + h(n), h = Euclidean estimate to ${destination}.`,
    distances: { ...gScore },
  })

  let nodesExplored = 0

  while (!pq.isEmpty()) {
    const { node: current } = pq.pop()

    if (visited.has(current)) continue
    visited.add(current)
    nodesExplored++

    steps.push({
      type: 'visit',
      node: current,
      distance: gScore[current],
      message: `Visiting ${current} (g = ${gScore[current].toFixed(1)}, h = ${h(current).toFixed(1)}, f = ${(gScore[current] + h(current)).toFixed(1)})`,
      pq: pq.toSortedArray().map(e => [Number(e.priority.toFixed(1)), e.node]),
    })

    if (current === destination) {
      steps.push({ type: 'reached', node: current, message: `Destination ${destination} reached.` })
      break
    }

    for (const { to: neighbor, roadId } of adjacencyList[current]) {
      if (visited.has(neighbor)) continue
      const road = roads[roadId]
      const weight = edgeCost(road, mode)
      const tentativeG = gScore[current] + weight

      if (tentativeG < gScore[neighbor]) {
        gScore[neighbor] = tentativeG
        previous[neighbor] = current
        const f = tentativeG + h(neighbor)
        pq.push(neighbor, f)

        steps.push({
          type: 'relax',
          from: current,
          to: neighbor,
          newDistance: tentativeG,
          message: `Relaxing edge ${current} → ${neighbor}: g = ${tentativeG.toFixed(1)}, f = ${f.toFixed(1)}`,
        })
      }
    }
  }

  const path = reconstructPath(previous, source, destination)
  const executionTime = performance.now() - startTime

  steps.push({
    type: 'done',
    message: path ? 'Reconstructing path... Shortest route found.' : 'No path exists to destination.',
  })

  return {
    algorithm: 'A*',
    path,
    distance: path ? gScore[destination] : null,
    distances: gScore,
    previous,
    steps,
    nodesExplored,
    executionTime,
  }
}
