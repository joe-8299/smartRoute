import { PriorityQueue } from './priorityQueue.js'
import { edgeCost } from '../utils/graphUtils.js'
import { reconstructPath } from '../utils/pathReconstruction.js'

/**
 * Dijkstra's Algorithm — manual implementation.
 *
 * 1. Set every node's distance to Infinity, source = 0.
 * 2. Push source into the min-heap priority queue.
 * 3. Pop the node with the smallest known distance.
 * 4. Examine all its neighbors (edge relaxation).
 * 5. If a shorter path to a neighbor is found, update distance + previous.
 * 6. Push the updated neighbor back into the queue.
 * 7. Repeat until the destination is popped (or queue empties).
 * 8. Reconstruct the path using the `previous` map.
 *
 * Time complexity:  O((V + E) log V)
 * Space complexity: O(V + E)
 */
export function dijkstra(adjacencyList, roads, source, destination, mode = 'distance') {
  const startTime = performance.now()

  const distances = {}
  const previous = {}
  const visited = new Set()
  const steps = []

  for (const node in adjacencyList) distances[node] = Infinity
  distances[source] = 0

  const pq = new PriorityQueue()
  pq.push(source, 0)

  steps.push({
    type: 'init',
    message: `Starting Dijkstra from ${source}. All distances set to ∞ except source = 0.`,
    distances: { ...distances },
  })

  let nodesExplored = 0

  while (!pq.isEmpty()) {
    const { node: current, priority: currentDist } = pq.pop()

    if (visited.has(current)) continue
    visited.add(current)
    nodesExplored++

    steps.push({
      type: 'visit',
      node: current,
      distance: currentDist,
      message: `Visiting ${current} (distance = ${currentDist.toFixed(1)})`,
      pq: pq.toSortedArray().map(e => [Number(e.priority.toFixed(1)), e.node]),
    })

    if (current === destination) {
      steps.push({ type: 'reached', node: current, message: `Destination ${destination} reached.` })
      break
    }

    for (const { to: neighbor, roadId } of adjacencyList[current]) {
      if (visited.has(neighbor)) continue
      const road = roads[roadId]
      const weight = edgeCost(road, mode)
      const newDist = distances[current] + weight

      if (newDist < distances[neighbor]) {
        distances[neighbor] = newDist
        previous[neighbor] = current
        pq.push(neighbor, newDist)

        steps.push({
          type: 'relax',
          from: current,
          to: neighbor,
          newDistance: newDist,
          message: `Relaxing edge ${current} → ${neighbor}: updating distance to ${newDist.toFixed(1)}`,
        })
      }
    }
  }

  const path = reconstructPath(previous, source, destination)
  const executionTime = performance.now() - startTime

  steps.push({
    type: 'done',
    message: path ? 'Reconstructing path... Shortest route found.' : 'No path exists to destination.',
  })

  return {
    algorithm: 'Dijkstra',
    path,
    distance: path ? distances[destination] : null,
    distances,
    previous,
    steps,
    nodesExplored,
    executionTime,
  }
}
