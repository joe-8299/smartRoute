// SmartRoute — Binary Min-Heap Priority Queue
// Used by both Dijkstra and A* to always pop the node with the
// smallest known priority (distance, or f(n) for A*) in O(log n).

export class PriorityQueue {
  constructor() {
    this.heap = [] // array of { priority, node }
  }

  get size() {
    return this.heap.length
  }

  isEmpty() {
    return this.heap.length === 0
  }

  push(node, priority) {
    this.heap.push({ node, priority })
    this._bubbleUp(this.heap.length - 1)
  }

  pop() {
    if (this.heap.length === 0) return null
    const top = this.heap[0]
    const last = this.heap.pop()
    if (this.heap.length > 0) {
      this.heap[0] = last
      this._bubbleDown(0)
    }
    return top
  }

  // Returns a snapshot sorted by priority, for UI display only.
  toSortedArray() {
    return [...this.heap].sort((a, b) => a.priority - b.priority)
  }

  _bubbleUp(i) {
    while (i > 0) {
      const parent = (i - 1) >> 1
      if (this.heap[parent].priority <= this.heap[i].priority) break
      ;[this.heap[parent], this.heap[i]] = [this.heap[i], this.heap[parent]]
      i = parent
    }
  }

  _bubbleDown(i) {
    const n = this.heap.length
    while (true) {
      let smallest = i
      const left = 2 * i + 1
      const right = 2 * i + 2
      if (left < n && this.heap[left].priority < this.heap[smallest].priority) smallest = left
      if (right < n && this.heap[right].priority < this.heap[smallest].priority) smallest = right
      if (smallest === i) break
      ;[this.heap[smallest], this.heap[i]] = [this.heap[i], this.heap[smallest]]
      i = smallest
    }
  }
}
