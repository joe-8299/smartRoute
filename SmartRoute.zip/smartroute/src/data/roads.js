// SmartRoute — Road Network Data
// Each entry is one undirected edge: [fromId, toId, baseDistanceKm]
// Distances are simulated for demonstration purposes.

export const roadDefinitions = [
  ['chennai', 'egmore', 4],
  ['chennai', 'nungambakkam', 6],
  ['egmore', 'nungambakkam', 3],
  ['nungambakkam', 'tnagar', 4],
  ['tnagar', 'mylapore', 5],
  ['mylapore', 'adyar', 6],
  ['tnagar', 'vadapalani', 5],
  ['tnagar', 'guindy', 7],
  ['adyar', 'guindy', 6],
  ['adyar', 'velachery', 8],
  ['chennai', 'ambattur', 14],
  ['ambattur', 'poonamallee', 8],
  ['ambattur', 'porur', 10],
  ['poonamallee', 'porur', 6],
  ['porur', 'vadapalani', 7],
  ['porur', 'manapakkam', 5],
  ['vadapalani', 'guindy', 6],
  ['manapakkam', 'guindy', 5],
  ['manapakkam', 'pallavaram', 9],
  ['guindy', 'velachery', 8],
  ['guindy', 'pallavaram', 12],
  ['velachery', 'pallikaranai', 6],
  ['velachery', 'perungudi', 7],
  ['pallavaram', 'chromepet', 5],
  ['chromepet', 'tambaram', 6],
  ['tambaram', 'vandalur', 9],
  ['tambaram', 'pallikaranai', 11],
  ['pallikaranai', 'medavakkam', 5],
  ['medavakkam', 'sholinganallur', 8],
  ['pallikaranai', 'sholinganallur', 9],
  ['perungudi', 'thoraipakkam', 4],
  ['thoraipakkam', 'sholinganallur', 5],
  ['sholinganallur', 'omr', 6],
  ['vandalur', 'medavakkam', 10],
  ['thoraipakkam', 'omr', 5],
  ['omr', 'navalur', 6],
  ['navalur', 'siruseri', 5],
  ['siruseri', 'kelambakkam', 5],
  ['omr', 'kelambakkam', 15],
]

// Traffic multipliers applied to base distance to get an effective cost
export const TRAFFIC_FACTORS = {
  LOW: 1.0,
  MEDIUM: 1.3,
  HIGH: 2.0,
  SEVERE: 3.0,
}

export function makeRoadId(a, b) {
  return [a, b].sort().join('__')
}

export function buildInitialRoads() {
  const roads = {}
  for (const [a, b, dist] of roadDefinitions) {
    const id = makeRoadId(a, b)
    roads[id] = {
      id,
      from: a,
      to: b,
      baseDistance: dist,
      traffic: 'LOW',
      closed: false,
    }
  }
  return roads
}
