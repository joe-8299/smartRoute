// SmartRoute — Location Data
// NOTE: Coordinates, distances and traffic values are SIMULATED for
// demonstration purposes only. They loosely follow the real relative
// geography of the Chennai metro area but are not survey-accurate.

export const locations = [
  { id: 'chennai',       name: 'Chennai Central', x: 430, y: 50 },
  { id: 'egmore',        name: 'Egmore',           x: 390, y: 85 },
  { id: 'nungambakkam',  name: 'Nungambakkam',     x: 345, y: 125 },
  { id: 'tnagar',        name: 'T Nagar',          x: 365, y: 178 },
  { id: 'mylapore',      name: 'Mylapore',         x: 440, y: 188 },
  { id: 'adyar',         name: 'Adyar',             x: 425, y: 240 },
  { id: 'ambattur',      name: 'Ambattur',         x: 175, y: 115 },
  { id: 'poonamallee',   name: 'Poonamallee',      x: 145, y: 200 },
  { id: 'porur',         name: 'Porur',            x: 220, y: 232 },
  { id: 'vadapalani',    name: 'Vadapalani',       x: 300, y: 210 },
  { id: 'manapakkam',    name: 'Manapakkam',       x: 262, y: 282 },
  { id: 'guindy',        name: 'Guindy',           x: 385, y: 272 },
  { id: 'velachery',     name: 'Velachery',        x: 425, y: 322 },
  { id: 'pallavaram',    name: 'Pallavaram',       x: 300, y: 342 },
  { id: 'chromepet',     name: 'Chromepet',        x: 320, y: 384 },
  { id: 'tambaram',      name: 'Tambaram',         x: 340, y: 434 },
  { id: 'vandalur',      name: 'Vandalur',         x: 300, y: 494 },
  { id: 'pallikaranai',  name: 'Pallikaranai',     x: 445, y: 372 },
  { id: 'medavakkam',    name: 'Medavakkam',       x: 420, y: 424 },
  { id: 'perungudi',     name: 'Perungudi',        x: 475, y: 340 },
  { id: 'thoraipakkam',  name: 'Thoraipakkam',     x: 505, y: 362 },
  { id: 'sholinganallur',name: 'Sholinganallur',   x: 485, y: 404 },
  { id: 'omr',           name: 'OMR Junction',     x: 525, y: 434 },
  { id: 'navalur',       name: 'Navalur',          x: 548, y: 472 },
  { id: 'siruseri',      name: 'Siruseri',         x: 565, y: 512 },
  { id: 'kelambakkam',   name: 'Kelambakkam',      x: 585, y: 554 },
]

export const locationById = Object.fromEntries(locations.map(l => [l.id, l]))
